<div class="cert-layer-options">
<!-- Content ajax go here! -->
</div>