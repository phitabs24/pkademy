{{email_heading}}

Hi {{username}},

The lesson "{{lesson_name}}" at {{lesson_url}} is coming soon to available on {{available_date}}!

Please login to your account here {{login_url}} and starting to learn

Best Regards,

{{site_title}}

{{footer_text}}